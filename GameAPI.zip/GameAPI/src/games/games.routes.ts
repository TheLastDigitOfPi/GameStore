import { Router } from "express";
import * as GamessController from './games.controller';
//Defines routes for application so that certain functions are called upon route request
const router = Router();
router
    .route('/games')
    .get(GamessController.readGames);

router
    .route('/games/:Platform')
    .get(GamessController.readGamesByPlatform);
    
router
    .route('/games/search/name/:search')
    .get(GamessController.readGamesByNameSearch);

router
    .route('/games/search/description/:search')
    .get(GamessController.readGamesByDescriptionSearch);

router
    .route('/games')
    .post(GamessController.createGame);

router
    .route('/games')
    .put(GamessController.updateGame);

router
    .route('/games/:gameId')
    .delete(GamessController.deleteGame);

export default router;