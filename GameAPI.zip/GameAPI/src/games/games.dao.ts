import { OkPacket } from 'mysql';
import { execute } from '../services/mysql.connector';
import { Game } from './games.model';
import {gameQueries} from './games.queries';

//Middleman to execute SQL queries with request gathered from route

export const readGames =async () => {
    return execute<Game[]>(gameQueries.readGames, []);
};

export const readGamesByPlatform =async (platform: string) => {
    return execute<Game[]>(gameQueries.readGamesByPlatform, [platform]);
};

export const readGamesByNameSearch =async (search: string) => {
    console.log('search param', search);
    return execute<Game[]>(gameQueries.readGamesByNameSearch, [search]);
};

export const readGamesByDescriptionSearch =async (search: string) => {
    console.log('search param', search);
    return execute<Game[]>(gameQueries.readGamesByDescriptionSearch, [search]);
};

export const readGamesByGameId =async (GameID: number) => {
    return execute<Game[]>(gameQueries.readGamesByGameId, [GameID]);
};

export const createGame =async (game: Game) => {
    console.log('body data', game);
    return execute<OkPacket>(gameQueries.createGame,
       [game.Name, game.Price,game.Rating, game.Description, game.Platform, game.Image]);
};

export const updateGame =async (game:Game) => {
    return execute<OkPacket>(gameQueries.updateGame,
        [game.Name, game.Price, game.Rating, game.Description, game.Platform, game.Image, game.ID]);
};

export const deleteGame =async (gameId:number) => {
    return execute<OkPacket>(gameQueries.deleteGame, [gameId]);
}