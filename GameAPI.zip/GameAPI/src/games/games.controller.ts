import { Request,RequestHandler ,Response } from "express";
import {Game} from './games.model';
import * as GameDao from './games.dao';
import { OkPacket } from "mysql";

//Functions to be called when user sends request to a route

//Read games from database, if an ID is given only send game with that ID
export const readGames : RequestHandler =async (req: Request, res: Response) => {
    try{
        let games;
        let gameId = parseInt(req.query.gameId as string);

        console.log('gameId', gameId);
        if(Number.isNaN(gameId)){
            games = await GameDao.readGames();
        }else{
            games = await GameDao.readGamesByGameId(gameId);
        }
        res.status(200).json(
            games
        );
    }catch(error){
        console.error('[games.controller][readGames][Error] ', error);
        res.status(500).json({
            message: 'There was an error when fetching games'
        });
    }
};

//Read games by their platform. Exact spelling needed
export const readGamesByPlatform: RequestHandler =async (req:Request, res:Response) => {
    try{
        const games = await GameDao.readGamesByPlatform(req.params.Platform);

        res.status(200).json(games);
    }catch(error){
        console.error('[games.controller][readGames][Error] ', error);
        res.status(500).json({
            message: 'There was an error when fetching games'
        });
    }
}
//Search database for games based off name
export const readGamesByNameSearch: RequestHandler =async (req:Request, res:Response) => {
    try{
        console.log('search', req.params.search);
        const games = await GameDao.readGamesByNameSearch('%' + req.params.search + '%');
        res.status(200).json(games);
    }catch (error)
    {
        console.error('[games.controller][readGames][Error] ', error);
        res.status(500).json({
            message: 'There was an error when fetching games'
        });
    }
}
//Search database for games based off description
export const readGamesByDescriptionSearch: RequestHandler =async (req:Request, res:Response) => {
    try{
        console.log('search', req.params.search);
        const games = await GameDao.readGamesByDescriptionSearch('%' + req.params.search + '%');
        res.status(200).json(games);
    }catch (error)
    {
        console.error('[games.controller][readGames][Error] ', error);
        res.status(500).json({
            message: 'There was an error when fetching games'
        });
    }
}
//Create a game to add to the database
export const createGame: RequestHandler =async (req:Request, res:Response) => {
    try{

       const okPacket: OkPacket = await GameDao.createGame(req.body);

        console.log('req.body', req.body);
        
        console.log('game', okPacket);

        res.status(200).json(okPacket);
        
        console.log('Created Game Successfully');
    }catch (error)
    {
        console.log('req.body was', req.body); 
        console.error('[games.controller][createGames][Error] ', error);
        res.status(500).json({
            message: 'There was an error when writing games'
        });
    }
}
//Update a game in the database based off an ID of an already created Game
export const updateGame: RequestHandler =async (req:Request, res: Response) => {
    try{
        const okPacket: OkPacket = await GameDao.updateGame(req.body);

        console.log('req.body', req.body);
        console.log('game',okPacket);

        res.status(200).json(
            okPacket
        );
    }catch(error){

       console.log('req.body was', req.body); 
       console.error('[games.controller][updateGames][Error] ', error);
        
        res.status(500).json({
            message: 'There was an error when updating games'
        });
    }
};

//Delete a game from the database based by its ID
export const deleteGame: RequestHandler =async (req:Request, res: Response) => {
    try{
        let gameId = parseInt(req.params.gameId as string);

        console.log('gameId', gameId);
        if(!Number.isNaN(gameId)){
            const response = await GameDao.deleteGame(gameId);

            res.status(200).json(
                response
            );
        }else{
            throw new Error("Integer exepected for gameId");
        }
    }catch(error){
        console.error('[games.controller][deletedGame][Error] ', error);
        res.status(500).json({
            message: 'There was an error when deleting game'
        });
    }
};