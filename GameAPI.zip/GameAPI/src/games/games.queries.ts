//Queries to be sent to SQL server to perform CRUD opperations
export const gameQueries = {
    readGames:`
    SELECT
    Id as ID, Name as Name, Price as Price, Rating as Rating,Description as Description, Platform as Platform, image as image
    from gamestore.games
    `,
    readGamesByPlatform: `
    SELECT 
    Id as ID, Name as Name, Price as Price, Rating as Rating,Description as Description, Platform as Platform, image as image
    from gamestore.games
    where gamestore.games.Platform = ?
    `,
    readGamesByNameSearch: `
    SELECT 
    Id as ID, Name as Name, Price as Price, Rating as Rating,Description as Description, Platform as Platform, image as image
    from gamestore.games
    where gamestore.games.Name LIKE ?
    `,
    readGamesByDescriptionSearch: `
    SELECT 
    Id as ID, Name as Name, Price as Price, Rating as Rating,Description as Description, Platform as Platform, image as image
    from gamestore.games
    where gamestore.games.Description LIKE ?
    `,
    readGamesByGameId: `
    SELECT 
    Id as ID, Name as Name, Price as Price, Rating as Rating,Description as Description, Platform as Platform, image as image
    from gamestore.games
    where gamestore.games.id = ?
    `,
    createGame: `
    INSERT INTO games(Name, Price, Rating, Description, Platform, image) Values(?,?,?,?,?,?)
    `,
    updateGame: `
    UPDATE gamestore.games
    set Name = ?, Price = ?, Rating = ?, Description = ?, Platform = ?, Image = ?
    where Id = ?
    `,
    deleteGame: `
    delete from gamestore.games
    where Id = ?
    `,
}