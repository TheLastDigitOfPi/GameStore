export interface Game {
    ID: number;
    Name: string;
    Price: number;
    Rating: string;
    Description: string;
    Platform: string;
    Image: string;
}