import express, { Request, Response } from 'express';
import gamesRouter from './games/games.routes';
import logger from './middleware/logger.middleware';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = 3000;

if(process.env.NODE_ENV == 'development')
{
    //add logger middleware
    app.use(logger);
    console.log(process.env.GREETING + ' in dev mode');
}
//Parse JSON bodies
app.use(express.json());
//Parse URL-encoded bodies
app.use(express.urlencoded({extended:true}));
// enable all CORS request
app.use(cors());
//adding set of security middleware
app.use(helmet());

//Route Application
app.use('/', [gamesRouter]);
//Start application to listen on port
app.listen(port, () => {  console.log(`Example app listening at http://localhost:${port}`)});
